package antifraud.repository;

import antifraud.entity.Transaction;
import org.springframework.data.repository.CrudRepository;

public interface TransactionRepository extends CrudRepository<Transaction, Long> {


    Transaction save(Transaction entity);
}