package antifraud.entity;

public enum Region {
    EAP,
    ECA,
    HIC,
    LAC,
    MENA,
    SA,
    SSA
}
